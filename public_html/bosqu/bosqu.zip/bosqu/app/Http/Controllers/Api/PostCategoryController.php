<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PostCategory;
use Exception;
use Illuminate\Http\Request;

class PostCategoryController extends Controller
{
    public function index()
    {
        try {
            $data = PostCategory::all();
            return response()->json($data, 200);
        } catch (Exception $e) {
            // throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function show($id)
    {
        try {
            //code...
            $data = PostCategory::find($id);
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function store(Request $request)
    {
        try {
            //code...
            $data = PostCategory::create($request->all());
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $id)
    {
        // $data = "DATA ROLE UPDATE ID " . $id;
        try {
            //code...
            $data = PostCategory::find($id)->update($request->all());
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        try {
            //code...
            $data = PostCategory::destroy($id);
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
