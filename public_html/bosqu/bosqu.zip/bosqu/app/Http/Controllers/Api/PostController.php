<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    public function index()
    {
        try {
            $data = Post::all();
            return response()->json($data, 200);
        } catch (Exception $e) {
            // throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function show($id)
    {
        try {
            //code...
            $data = Post::find($id);
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function store(Request $request)
    {
        try {
            //code...
            $request['user_id'] = Auth::user()->id;
            // $request['slug'] = Str::slug($title);

            $filename = $request->gambar->getClientOriginalName();

            if ($request->file('gambar') != null) {
                $request->file('gambar')->storeAs('posts', $filename, 'public');
            } else {
                $filename = 'default.jpg';
            }

            $request['gambar'] = $request->file('gambar')->getClientOriginalName();

            $data = Post::create($request->all());
            $data->gambar = $filename;
            $data->save();

            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $id)
    {
        // return $request;
        try {
            Post::where('id', $id)->update($request->all());
            $data = Post::find($id);
            return response()->json(['message' => 'Data berhasil diubah', 'data' => $data], 200);
            // return $request;
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        try {
            //code...
            $data = Post::find($id)->delete();
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
