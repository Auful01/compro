<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $data = Product::all();
            return response()->json($data, 200);
        } catch (Exception $e) {
            // throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function getByUser()
    {
        # code...
        try {
            $data = Product::where('user_id', Auth::user()->id)->get();
            return response()->json($data, 200);
        } catch (Exception $e) {
            // throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            //code...
            $request['user_id'] = Auth::user()->id;

            $filename = $request->file('gambar')->getClientOriginalName();

            if ($request->file('gambar') != null) {
                $request->file('gambar')->storeAs('products', $filename, 'public');
            } else {
                $filename = 'default.jpg';
            }

            $request['gambar'] = $request->file('gambar')->getClientOriginalName();

            $data = Product::create($request->all());
            $data->gambar = $filename;
            $data->save();

            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            //code...
            $data = Product::find($id);
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function showByUser($id)
    {
        try {
            //code...
            $data = Product::where('user_id', Auth::user()->id)->where('id', $id)->get();
            if ($data->count() > 0) {
                return response()->json($data, 200);
            } else {
                return response()->json(['error' => 'Data tidak ditemukan'], 404);
            }
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // return $request;
        try {
            //code...
            Product::where('id', $id)->update($request->all());
            $data = Product::find($id);
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function updateByUser(Request $request, $id)
    {
        // return $request;
        try {
            //code...
            $update = Product::where('id', $id)->where('user_id', Auth::user()->id)->update($request->all());
            if (!$update) {
                return response()->json(['error' => 'Data tidak ditemukan, Update Gagal'], 404);
            } else {
                $data = Product::find($id);
                return response()->json($data, 200);
            }
            // $data = Product::find($id);
            // return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            //code...
            $data = Product::find($id);
            $data->delete();
            return response()->json($data, 200);
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function destroyByUser($id)
    {
        try {
            //code...
            $data = Product::where('id', $id)->where('user_id', Auth::user()->id)->delete();
            if (!$data) {
                return response()->json(['error' => 'Data tidak ditemukan'], 404);
            } else {
                return response()->json($data, 200);
            }
        } catch (Exception $e) {
            //throw $th;
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
