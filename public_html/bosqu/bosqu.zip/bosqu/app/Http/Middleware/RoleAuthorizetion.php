<?php

namespace App\Http\Middleware;

use App\Models\Profile;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Http\Middleware\BaseMiddleware;

class RoleAuthorizetion extends BaseMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next, ...$roles)
    {
        // return $next($request);
        try {
            // $token = JWTAuth::parseToken();

            $user = $this->auth->parseToken()->authenticate();
        } catch (TokenInvalidException $e) {
            return response()->json(['error' => 'Token is Invalid'], 401);
        } catch (TokenExpiredException $e) {
            return response()->json(['error' => 'Token is Expired'], 401);
        } catch (JWTException $e) {
            return response()->json(['error' => 'Authorization Token not found'], 401);
        }

        // dd(Auth::check());
        if ($user && in_array($user->role->role, $roles)) {
            $find = Profile::with('user')->where('user_id', $user->id)->first();
            // dd($find->verifikasi);
            if ($find->user->role->role == 'umkm') {
                if ($find->verifikasi == 1) {
                    return $next($request);
                } else {
                    return response()->json(['error' => 'Anda belum diverifikasi'], 401);
                }
            } else {
                return $next($request);
            }
        }
        // return $this->unauthorized();
        return response()->json(['error' => 'You are not authorized'], 401);
    }

    private function unauthorized($message = null)
    {
        return response()->json(['error' => $message ?: 'Unauthorized'], 401);
    }
}
