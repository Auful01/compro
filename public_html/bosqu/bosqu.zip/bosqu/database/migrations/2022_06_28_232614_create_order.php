<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('product_id');
            $table->unsignedBigInteger('alamat_id');
            $table->text('alamat_lain');
            $table->integer('jumlah');
            $table->integer('total');
            $table->enum('status_pembayaran', [0, 1])->default(0);
            $table->string('bukti_pembayaran')->nullable();
            $table->enum('status_pengiriman', ['menunggu', 'proses', 'dikirim', 'selesai'])->default('menunggu');
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('product')->onDelete('cascade');
            $table->foreign('alamat_id')->references('id')->on('tipe_alamat')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order');
    }
};
