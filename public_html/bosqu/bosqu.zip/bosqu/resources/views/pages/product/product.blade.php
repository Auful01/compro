
    <div class="row">
        <div class="col-md-auto">
            <div class="card shadow">
                <div class="card-body">
                    <div class="product">

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-auto">
            <div class="card shadow">
                <div class="card-body">
                    <div class="product">

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-auto">
            <div class="card shadow">
                <div class="card-body">
                    <div class="product">

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('.product').html('coba tak isi USER')
        })
    </script>
