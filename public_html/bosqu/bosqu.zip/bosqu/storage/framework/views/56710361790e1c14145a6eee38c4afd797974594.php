

<div class="card shadow mt-5 border-0" >
        <div class="card-body">
            <div class="table-responsive">
                <table id="posts-table" class="table table-hovered">
                    <thead>
                        <th>No</th>
                        <th>Title</th>
                        <th>Gambar</th>
                        <th>Content</th>
                    </thead>
                    <tbody>
                        <tr id="posts-body">

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('.coba').html('coba tak isi sesuatu')

            $.ajax({
                url: '/api/posts/',
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    console.log(data)
                    $('body #posts-table').DataTable({
                        data: data,
                        columns: [
                            { data: 'id' },
                            { data: 'judul' },
                            { data: 'gambar' },
                            { data: 'konten' },
                        ]
                    })
                    // $('#posts-body').html(data)
                }
            })
        })
    </script>
<?php /**PATH E:\USAHA\MRXtech\BosQu\bosqu\resources\views/pages/posts/posts.blade.php ENDPATH**/ ?>